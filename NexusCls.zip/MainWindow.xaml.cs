﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading; // Do Timerów

namespace NexusCls
{
    public class WindowConfig
    {
        public double Top { get; set; }
        public double Left { get; set; }
    }

    [StructLayout(LayoutKind.Sequential)]
    struct LASTINPUTINFO
    {
        public static readonly int SizeOf = Marshal.SizeOf(typeof(LASTINPUTINFO));
        [MarshalAs(UnmanagedType.U4)]
        public UInt32 cbSize;
        [MarshalAs(UnmanagedType.U4)]
        public UInt32 dwTime;
    }

    public partial class MainWindow : Window
    {
        // --- SEKCJA WINAPI ---
        [DllImport("user32.dll")]
        static extern IntPtr SendMessage(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);

        [DllImport("user32.dll")]
        static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);

        // Dodajemy import do odczytu stanu klawiszy (dla ESC)
        [DllImport("user32.dll")]
        public static extern short GetAsyncKeyState(int vKey);

        const uint WM_SYSCOMMAND = 0x0112;
        const int SC_MONITORPOWER = 0xF170;
        const int MONITOR_OFF = 2;
        const int VK_ESCAPE = 0x1B; // Kod klawisza ESC

        private const string ConfigFileName = "window_config.json";

        // Timer 1: Wysyła sygnał OFF co 30 sekund (zabezpieczenie)
        private DispatcherTimer _forceOffTimer;

        // Timer 2: Sprawdza klawisz ESC i "kontruje" ruch myszy
        private DispatcherTimer _exitCheckTimer;

        // Zmienna do kontroli częstotliwości wysyłania komendy OFF (anty-spam)
        private long _lastOffCommandTime = 0;

        public MainWindow()
        {
            InitializeComponent();

            // Konfiguracja Timera wymuszającego wyłączenie (co 30 sekund)
            _forceOffTimer = new DispatcherTimer();
            _forceOffTimer.Interval = TimeSpan.FromSeconds(30);
            _forceOffTimer.Tick += ForceOffTimer_Tick;

            // Konfiguracja Timera sprawdzającego wejście
            // Zwiększamy interwał do 200ms (5 razy na sekundę) - to wystarczy i mniej obciąża CPU
            _exitCheckTimer = new DispatcherTimer();
            _exitCheckTimer.Interval = TimeSpan.FromMilliseconds(200);
            _exitCheckTimer.Tick += ExitCheckTimer_Tick;
        }

        // --- TIMER 1: WYMUSZANIE WYŁĄCZENIA ---
        private void ForceOffTimer_Tick(object sender, EventArgs e)
        {
            // Bez pytania o zgodę, wysyłamy sygnał OFF
            SendMonitorOff();
        }

        // --- TIMER 2: WYKRYWANIE ESC I RUCHU ---
        private void ExitCheckTimer_Tick(object sender, EventArgs e)
        {
            // 1. Sprawdzamy czy wciśnięto ESC (bit 0x8000 oznacza wciśnięcie)
            // Używamy GetAsyncKeyState, co jest bezpieczne i nie "hookuje" klawiatury systemowo.
            if ((GetAsyncKeyState(VK_ESCAPE) & 0x8000) != 0)
            {
                // Użytkownik wcisnął ESC -> Zamykamy program, wybudzamy ekran
                Application.Current.Shutdown();
                return;
            }

            // 2. Jeśli ESC nie jest wciśnięte, sprawdzamy czy był inny ruch (np. myszka)
            uint idleTime = GetIdleTime();

            // Jeśli czas bezczynności jest bardzo mały (< 500ms), znaczy że ktoś rusza myszką
            if (idleTime < 500)
            {
                // Zabezpieczenie przed spamowaniem komendy OFF co ułamek sekundy.
                // Wysyłamy komendę tylko jeśli od ostatniej minęła co najmniej 1 sekunda (1000ms).
                long currentTime = Environment.TickCount64;
                if (currentTime - _lastOffCommandTime > 1000)
                {
                    SendMonitorOff();
                    _lastOffCommandTime = currentTime;
                }
            }
        }

        private void SendMonitorOff()
        {
            var helper = new System.Windows.Interop.WindowInteropHelper(this);
            SendMessage(helper.Handle, WM_SYSCOMMAND, (IntPtr)SC_MONITORPOWER, (IntPtr)MONITOR_OFF);
        }

        private uint GetIdleTime()
        {
            LASTINPUTINFO lastInput = new LASTINPUTINFO();
            lastInput.cbSize = (uint)Marshal.SizeOf(lastInput);
            lastInput.dwTime = 0;

            if (GetLastInputInfo(ref lastInput))
            {
                return (uint)Environment.TickCount - lastInput.dwTime;
            }
            return 0;
        }

        // --- OBSŁUGA POZYCJI OKNA (JSON) ---
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                if (File.Exists(ConfigFileName))
                {
                    string jsonString = File.ReadAllText(ConfigFileName);
                    var config = JsonSerializer.Deserialize<WindowConfig>(jsonString);
                    if (config != null)
                    {
                        this.Top = config.Top;
                        this.Left = config.Left;
                        EnsureWindowIsVisible();
                        return;
                    }
                }
            }
            catch { }
            CenterWindow();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // Zatrzymujemy timery przy zamykaniu, dla porządku
            _forceOffTimer?.Stop();
            _exitCheckTimer?.Stop();

            try
            {
                var config = new WindowConfig { Top = this.Top, Left = this.Left };
                string jsonString = JsonSerializer.Serialize(config);
                File.WriteAllText(ConfigFileName, jsonString);
            }
            catch { }
        }

        private void CenterWindow()
        {
            double screenWidth = SystemParameters.PrimaryScreenWidth;
            double screenHeight = SystemParameters.PrimaryScreenHeight;
            this.Left = (screenWidth - this.Width) / 2;
            this.Top = (screenHeight - this.Height) / 2;
        }

        private void EnsureWindowIsVisible() { }

        // --- LOGIKA PRZYCISKU START ---
        private async void TurnOffButton_Click(object sender, RoutedEventArgs e)
        {
            TurnOffButton.Content = "Za 2 sekundy...";
            TurnOffButton.IsEnabled = false;

            // 1. Czekamy 2 sekundy
            await Task.Delay(2000);

            TurnOffButton.Content = "CZUWANIE...";

            // 2. Pierwsze wyłączenie ekranu
            SendMonitorOff();
            _lastOffCommandTime = Environment.TickCount64; // Zapamiętujemy czas wysłania

            // 3. Uruchamiamy pętlę "co 30 sekund popraw"
            _forceOffTimer.Start();

            // 4. Czekamy dodatkowe 2 sekundy
            await Task.Delay(2000);

            // 5. Dopiero teraz uruchamiamy sprawdzanie ESC
            _exitCheckTimer.Start();
        }

        private void CloseApp_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                this.DragMove();
            }
        }
    }
}